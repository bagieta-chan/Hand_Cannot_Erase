/*
 * timers.h
 *
 *  Created on: Sep 30, 2023
 *      Author: Aleksy
 */

#ifndef INC_TIMERS_H_
#define INC_TIMERS_H_
#include "accelerometre.h"

extern Accel acc_device;


void calculate_Tim2Period();
#endif /* INC_TIMERS_H_ */
